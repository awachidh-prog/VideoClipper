# Video Clipper — GitHub APK Build

1. Create a new GitHub repository.
2. Upload all files and folders from this project, including `.github/workflows/build-apk.yml`.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK**.
5. Click **Run workflow** (or push to `main`/`master`, which starts it automatically).
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run and find **Artifacts**.
8. Download `VideoClipper-debug-apk`, extract it, and install `app-debug.apk` on Android.

No Android Studio is required for the build machine.
