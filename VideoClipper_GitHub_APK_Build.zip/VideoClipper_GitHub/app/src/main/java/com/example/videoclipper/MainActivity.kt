package com.example.videoclipper

import android.content.ContentValues
import android.content.Intent
import android.media.*
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    private var selectedUri: Uri? = null
    private lateinit var status: TextView
    private lateinit var durationSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val title = TextView(this).apply {
            text = "Video Clipper"
            textSize = 28f
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        layout.addView(title)

        val subtitle = TextView(this).apply {
            text = "Potong video langsung di HP — tanpa cloud."
            textSize = 16f
            setPadding(0, 8, 0, 24)
        }
        layout.addView(subtitle)

        val pick = Button(this).apply { text = "Pilih Video" }
        layout.addView(pick)

        val chosen = TextView(this).apply {
            text = "Belum ada video dipilih"
            setPadding(0, 12, 0, 12)
        }
        layout.addView(chosen)

        val label = TextView(this).apply {
            text = "Durasi setiap klip:"
            setPadding(0, 8, 0, 4)
        }
        layout.addView(label)

        durationSpinner = Spinner(this)
        val values = arrayOf("15 detik", "30 detik", "60 detik")
        durationSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, values)
        layout.addView(durationSpinner)

        val process = Button(this).apply {
            text = "POTONG VIDEO"
            isAllCaps = false
        }
        layout.addView(process)

        status = TextView(this).apply {
            text = "Siap."
            textSize = 15f
            setPadding(0, 24, 0, 0)
        }
        layout.addView(status)

        setContentView(layout)

        pick.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "video/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            startActivityForResult(intent, 100)
        }

        process.setOnClickListener {
            val uri = selectedUri
            if (uri == null) {
                Toast.makeText(this, "Pilih video terlebih dahulu.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val seconds = when (durationSpinner.selectedItemPosition) {
                0 -> 15
                1 -> 30
                else -> 60
            }
            processVideo(uri, seconds)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) {
            selectedUri = data?.data
            findViewById<TextView>(android.R.id.content)?.let {}
            Toast.makeText(this, "Video dipilih.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun processVideo(uri: Uri, clipSeconds: Int) {
        status.text = "Memproses video…"
        Thread {
            try {
                val extractor = MediaExtractor()
                extractor.setDataSource(this, uri, null)

                var videoTrack = -1
                var audioTrack = -1
                for (i in 0 until extractor.trackCount) {
                    val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                    if (mime.startsWith("video/") && videoTrack < 0) videoTrack = i
                    if (mime.startsWith("audio/") && audioTrack < 0) audioTrack = i
                }
                if (videoTrack < 0) throw IllegalStateException("Video tidak ditemukan.")

                val videoFormat = extractor.getTrackFormat(videoTrack)
                val durationUs = videoFormat.getLong(MediaFormat.KEY_DURATION)
                val clipUs = clipSeconds * 1_000_000L
                val totalClips = ((durationUs + clipUs - 1) / clipUs).toInt()

                for (clip in 0 until totalClips) {
                    exportClip(uri, videoTrack, audioTrack, videoFormat,
                        clip.toLong() * clipUs, minOf((clip + 1L) * clipUs, durationUs), clip + 1)
                }

                runOnUiThread {
                    status.text = "Selesai! $totalClips klip disimpan di folder Movies/VideoClipper."
                    Toast.makeText(this, "Klip selesai dibuat.", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Gagal: ${e.message}" }
            }
        }.start()
    }

    private fun exportClip(
        uri: Uri, videoTrack: Int, audioTrack: Int, videoFormat: MediaFormat,
        startUs: Long, endUs: Long, index: Int
    ) {
        val extractor = MediaExtractor()
        extractor.setDataSource(this, uri, null)

        val date = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val name = "clip_${date}_${index}.mp4"

        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/VideoClipper")
        }
        val outUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Tidak bisa membuat file output.")

        contentResolver.openFileDescriptor(outUri, "w")!!.use { pfd ->
            val muxer = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            extractor.selectTrack(videoTrack)
            val outVideo = muxer.addTrack(videoFormat)

            var outAudio = -1
            if (audioTrack >= 0) {
                val af = extractor.getTrackFormat(audioTrack)
                outAudio = muxer.addTrack(af)
            }

            muxer.start()
            writeTrack(extractor, muxer, outVideo, startUs, endUs)

            if (audioTrack >= 0) {
                extractor.unselectTrack(videoTrack)
                extractor.selectTrack(audioTrack)
                writeTrack(extractor, muxer, outAudio, startUs, endUs)
            }

            muxer.stop()
            muxer.release()
        }
        extractor.release()
    }

    private fun writeTrack(
        extractor: MediaExtractor, muxer: MediaMuxer, track: Int,
        startUs: Long, endUs: Long
    ) {
        extractor.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
        val buffer = ByteBuffer.allocate(2 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        var firstPts = -1L

        while (true) {
            info.size = extractor.readSampleData(buffer, 0)
            if (info.size < 0) break
            val pts = extractor.sampleTime
            if (pts < 0 || pts >= endUs) break
            if (firstPts < 0) firstPts = pts

            info.presentationTimeUs = pts - firstPts
            info.offset = 0
            info.flags = extractor.sampleFlags
            muxer.writeSampleData(track, buffer, info)
            extractor.advance()
        }
    }
}
