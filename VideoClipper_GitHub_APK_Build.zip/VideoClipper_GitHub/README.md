# Video Clipper Android

Versi 1.0:
- Pilih video dari perangkat
- Pilih 15 / 30 / 60 detik
- Video dipotong menjadi beberapa file MP4
- Pemrosesan dilakukan langsung di HP
- Output disimpan ke Movies/VideoClipper

Catatan:
Versi ini belum mengambil video dari YouTube dan belum menggunakan AI untuk memilih momen.
